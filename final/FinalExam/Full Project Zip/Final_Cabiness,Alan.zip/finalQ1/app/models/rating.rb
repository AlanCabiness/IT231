class Rating < ApplicationRecord
end
