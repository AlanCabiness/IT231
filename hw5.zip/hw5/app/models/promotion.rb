class Promotion < ApplicationRecord
end
