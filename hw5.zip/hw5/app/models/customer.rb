class Customer < ApplicationRecord
  belongs_to :sale
end
