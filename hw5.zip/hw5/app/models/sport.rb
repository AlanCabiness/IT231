class Sport < ApplicationRecord
end
