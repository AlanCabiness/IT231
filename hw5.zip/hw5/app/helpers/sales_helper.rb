module SalesHelper
end
