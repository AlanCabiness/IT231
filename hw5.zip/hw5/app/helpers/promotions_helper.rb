module PromotionsHelper
end
