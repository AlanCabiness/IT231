class Gprice < ApplicationRecord
end
