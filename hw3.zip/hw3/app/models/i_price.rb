class IPrice < ApplicationRecord
end
