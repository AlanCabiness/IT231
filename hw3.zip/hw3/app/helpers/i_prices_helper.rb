module IPricesHelper
end
