class Promotion < ApplicationRecord
end
