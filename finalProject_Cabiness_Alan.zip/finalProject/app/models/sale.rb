class Sale < ApplicationRecord
end
